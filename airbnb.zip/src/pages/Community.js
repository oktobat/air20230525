import React, {useEffect, useState} from 'react';
import styled from 'styled-components'
import axios from 'axios'
import { ImSpinner } from 'react-icons/im';

const CommunitySection = styled.div`
    border-top:87px solid pink;
    .load { color:#000; font-size:100px; 
        display:flex; justify-content:center; align-items:center;
        .loadIcon { animation:loadSpin 5s linear infinite }
        @keyframes loadSpin {
            0% { transform:rotate(0deg) }
            100% { transform:rotate(3turn) }
        }
    }
`

const Community = () => {

    const [loading, setLoading] = useState(false)

    const getData = async ()=>{
        try {
            const response = axios.get('http://openapi.kepco.co.kr/service/EvInfoServiceV2/getEvSearchList?serviceKey=tsxcXyzF%2BXgzdg7s3iUG9BMSxzhXszdC68k9VquGWo9zq657lbmJPTjMzeWFsX5JhFXJvf8Yfgeh56Vou5hiog%3D%3D&pageNo=1&numOfRows=10&addr=%EC%A0%84%EB%9D%BC%EB%82%A8%EB%8F%84%20%EB%82%98%EC%A3%BC%EC%8B%9C%20%EB%B9%9B%EA%B0%80%EB%9E%8C%EB%8F%99%20120')
            console.log(response)
            setLoading(true)
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(()=>{
        getData()
    }, [])

    if (!loading) {
        return (
            <CommunitySection>
                <div className="row">
                    <div className="load">
                        <ImSpinner className="loadIcon" />
                    </div>
                </div>
            </CommunitySection>
        );
    } else {
        return (
            <CommunitySection>
               데이터 로딩 완료
            </CommunitySection>
        );
    }

    
};

export default Community;